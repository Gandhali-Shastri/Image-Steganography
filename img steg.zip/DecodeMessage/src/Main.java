
public class Main {
    public static void main(String arg[]) {
    NewJFrame a=new NewJFrame();
    a.setVisible(true);
    a.setLocationRelativeTo(null);
    }
}
